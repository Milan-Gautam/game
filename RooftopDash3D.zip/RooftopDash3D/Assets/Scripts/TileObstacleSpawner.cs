using UnityEngine;

public class TileObstacleSpawner : MonoBehaviour
{
    [Header("Prefabs (assign in Inspector)")]
    public GameObject lowObstaclePrefab;   // jump over
    public GameObject highObstaclePrefab;  // slide under
    public GameObject fullObstaclePrefab;  // must switch lane
    public GameObject coinPrefab;

    public float[] laneX = { -2.5f, 0f, 2.5f };
    public float tileLength = 10f;

    Transform content;

    void Awake()
    {
        content = new GameObject("Content").transform;
        content.SetParent(transform, false);
    }

    public void Populate()
    {
        for (int i = content.childCount - 1; i >= 0; i--)
        {
            Destroy(content.GetChild(i).gameObject);
        }

        float roll = Random.value;
        float midZ = tileLength * 0.5f;

        if (roll < 0.38f)
        {
            int lane = Random.Range(0, 3);
            GameObject prefab = Random.value < 0.5f ? lowObstaclePrefab : highObstaclePrefab;
            SpawnAt(prefab, lane, midZ);
        }
        else if (roll < 0.68f)
        {
            int openLane = Random.Range(0, 3);
            for (int lane = 0; lane < 3; lane++)
            {
                if (lane != openLane) SpawnAt(fullObstaclePrefab, lane, midZ);
            }
        }
        else if (roll < 0.86f)
        {
            GameObject prefab = Random.value < 0.5f ? lowObstaclePrefab : highObstaclePrefab;
            for (int lane = 0; lane < 3; lane++) SpawnAt(prefab, lane, midZ);
        }
        else
        {
            int[] lanes = { 0, 1, 2 };
            Shuffle(lanes);
            SpawnAt(fullObstaclePrefab, lanes[0], midZ);
            GameObject prefab = Random.value < 0.5f ? lowObstaclePrefab : highObstaclePrefab;
            SpawnAt(prefab, lanes[1], midZ * 1.6f);
        }

        if (Random.value < 0.55f)
        {
            int lane = Random.Range(0, 3);
            int count = Random.Range(3, 6);
            float spacing = 1.4f;
            float startZ = 1.5f;
            for (int i = 0; i < count; i++)
            {
                SpawnAt(coinPrefab, lane, startZ + i * spacing);
            }
        }
    }

    void SpawnAt(GameObject prefab, int lane, float localZ)
    {
        if (prefab == null) return;
        GameObject obj = Instantiate(prefab, content);
        obj.transform.localPosition = new Vector3(laneX[lane], 0f, localZ);
    }

    void Shuffle(int[] arr)
    {
        for (int i = arr.Length - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            int tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
    }
}
