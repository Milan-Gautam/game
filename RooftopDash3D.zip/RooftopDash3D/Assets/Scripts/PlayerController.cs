using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public enum Pose { Run, Jump, Slide }

    [Header("Lanes")]
    public float[] lanePositions = { -2.5f, 0f, 2.5f };
    public int currentLane = 1;
    public float laneChangeSpeed = 14f;

    [Header("Jump / Slide")]
    public float jumpHeight = 2.2f;
    public float gravity = -30f;
    public float slideDuration = 0.6f;

    public Pose CurrentPose { get; private set; } = Pose.Run;

    CharacterController controller;
    float verticalVelocity;
    float slideTimer;
    float standHeight, standCenterY;
    Vector2 touchStart;
    bool touchActive;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        standHeight = controller.height;
        standCenterY = controller.center.y;
    }

    void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.IsGameOver) return;

        HandleInput();
        HandleSlideTimer();
        HandleVertical();
        HandleLaneMovement();
        HandleForwardMovement();
    }

    void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) ChangeLane(-1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) ChangeLane(1);
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space)) Jump();
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) Slide();

        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Began)
            {
                touchStart = t.position;
                touchActive = true;
            }
            else if (t.phase == TouchPhase.Ended && touchActive)
            {
                touchActive = false;
                Vector2 delta = t.position - touchStart;
                if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y))
                {
                    if (Mathf.Abs(delta.x) > 60f) ChangeLane(delta.x > 0 ? 1 : -1);
                }
                else
                {
                    if (delta.y > 60f) Jump();
                    else if (delta.y < -60f) Slide();
                }
            }
        }
    }

    void ChangeLane(int dir)
    {
        int target = currentLane + dir;
        if (target < 0 || target >= lanePositions.Length) return;
        currentLane = target;
    }

    void Jump()
    {
        if (CurrentPose != Pose.Run) return;
        CurrentPose = Pose.Jump;
        verticalVelocity = Mathf.Sqrt(-2f * gravity * jumpHeight);
    }

    void Slide()
    {
        if (CurrentPose != Pose.Run) return;
        CurrentPose = Pose.Slide;
        slideTimer = slideDuration;
        controller.height = standHeight * 0.5f;
        controller.center = new Vector3(controller.center.x, standCenterY * 0.5f, controller.center.z);
    }

    void HandleSlideTimer()
    {
        if (CurrentPose != Pose.Slide) return;
        slideTimer -= Time.deltaTime;
        if (slideTimer <= 0f)
        {
            CurrentPose = Pose.Run;
            controller.height = standHeight;
            controller.center = new Vector3(controller.center.x, standCenterY, controller.center.z);
        }
    }

    void HandleVertical()
    {
        if (controller.isGrounded && CurrentPose == Pose.Jump && verticalVelocity <= 0f)
        {
            CurrentPose = Pose.Run;
        }

        if (!controller.isGrounded || CurrentPose == Pose.Jump)
        {
            verticalVelocity += gravity * Time.deltaTime;
        }
        else
        {
            verticalVelocity = -2f; // keeps controller grounded
        }

        controller.Move(new Vector3(0f, verticalVelocity, 0f) * Time.deltaTime);
    }

    void HandleLaneMovement()
    {
        float targetX = lanePositions[currentLane];
        float currentX = transform.position.x;
        float newX = Mathf.MoveTowards(currentX, targetX, laneChangeSpeed * Time.deltaTime);
        float deltaX = newX - currentX;
        controller.Move(new Vector3(deltaX, 0f, 0f));
    }

    void HandleForwardMovement()
    {
        float speed = GameManager.Instance.CurrentSpeed;
        controller.Move(Vector3.forward * speed * Time.deltaTime);
    }
}
