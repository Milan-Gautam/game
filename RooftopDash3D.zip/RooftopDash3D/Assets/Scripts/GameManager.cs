using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("UI (assign in Inspector)")]
    public Text scoreText;
    public Text bestScoreText;
    public GameObject gameOverPanel;
    public Text finalScoreText;

    [Header("Difficulty")]
    public float startSpeed = 8f;
    public float maxSpeed = 20f;
    public float speedRampPerSecond = 0.25f;

    public float CurrentSpeed { get; private set; }
    public float Score { get; private set; }
    public bool IsGameOver { get; private set; }

    float elapsed;
    const string BEST_KEY = "RooftopDash3D_Best";

    void Awake()
    {
        Instance = this;
        CurrentSpeed = startSpeed;
        Time.timeScale = 1f;
    }

    void Start()
    {
        float best = PlayerPrefs.GetFloat(BEST_KEY, 0f);
        if (bestScoreText) bestScoreText.text = "Best: " + Mathf.FloorToInt(best);
        if (gameOverPanel) gameOverPanel.SetActive(false);
    }

    void Update()
    {
        if (IsGameOver) return;

        elapsed += Time.deltaTime;
        CurrentSpeed = Mathf.Min(maxSpeed, startSpeed + elapsed * speedRampPerSecond);
        Score += CurrentSpeed * Time.deltaTime * 2f;

        if (scoreText) scoreText.text = Mathf.FloorToInt(Score).ToString();
    }

    public void AddScore(float amount)
    {
        Score += amount;
    }

    public void GameOver()
    {
        if (IsGameOver) return;
        IsGameOver = true;

        float best = PlayerPrefs.GetFloat(BEST_KEY, 0f);
        if (Score > best)
        {
            best = Score;
            PlayerPrefs.SetFloat(BEST_KEY, best);
        }

        if (gameOverPanel)
        {
            gameOverPanel.SetActive(true);
            if (finalScoreText)
            {
                finalScoreText.text = "Score: " + Mathf.FloorToInt(Score) + "   Best: " + Mathf.FloorToInt(best);
            }
        }
    }

    public void Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
