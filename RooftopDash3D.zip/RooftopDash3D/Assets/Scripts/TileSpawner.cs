using System.Collections.Generic;
using UnityEngine;

public class TileSpawner : MonoBehaviour
{
    public Transform player;
    public GameObject tilePrefab;
    public int tilesOnScreen = 6;
    public float tileLength = 10f;
    public float recycleOffsetBehind = 15f;

    readonly List<GameObject> activeTiles = new List<GameObject>();
    float nextSpawnZ = 0f;

    void Start()
    {
        for (int i = 0; i < tilesOnScreen; i++)
        {
            SpawnTile();
        }
    }

    void Update()
    {
        if (activeTiles.Count == 0 || player == null) return;

        GameObject first = activeTiles[0];
        if (player.position.z - first.transform.position.z > tileLength + recycleOffsetBehind)
        {
            RecycleTile(first);
        }
    }

    void SpawnTile()
    {
        GameObject tile = Instantiate(tilePrefab, new Vector3(0f, 0f, nextSpawnZ), Quaternion.identity);
        nextSpawnZ += tileLength;
        activeTiles.Add(tile);

        TileObstacleSpawner spawner = tile.GetComponent<TileObstacleSpawner>();
        if (spawner != null) spawner.Populate();
    }

    void RecycleTile(GameObject tile)
    {
        activeTiles.RemoveAt(0);
        tile.transform.position = new Vector3(0f, 0f, nextSpawnZ);
        nextSpawnZ += tileLength;
        activeTiles.Add(tile);

        TileObstacleSpawner spawner = tile.GetComponent<TileObstacleSpawner>();
        if (spawner != null) spawner.Populate();
    }
}
