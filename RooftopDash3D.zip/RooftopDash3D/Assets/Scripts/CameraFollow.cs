using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 4f, -7f);
    public float positionSmooth = 8f;
    public float lookSmooth = 8f;
    public Vector3 lookOffset = new Vector3(0f, 1.2f, 4f);

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desiredPos = new Vector3(
            Mathf.Lerp(transform.position.x, target.position.x + offset.x, positionSmooth * Time.deltaTime),
            target.position.y + offset.y,
            target.position.z + offset.z
        );
        transform.position = desiredPos;

        Vector3 lookAt = target.position + lookOffset;
        Quaternion desiredRot = Quaternion.LookRotation(lookAt - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, desiredRot, lookSmooth * Time.deltaTime);
    }
}
