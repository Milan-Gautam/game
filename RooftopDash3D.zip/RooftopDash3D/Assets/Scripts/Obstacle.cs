using UnityEngine;

public enum ObstacleType { Low, High, Full }

// Attach to obstacle prefabs. Collider on this object must have "Is Trigger" checked.
public class Obstacle : MonoBehaviour
{
    public ObstacleType type;

    void OnTriggerEnter(Collider other)
    {
        PlayerController player = other.GetComponent<PlayerController>();
        if (player == null) return;

        bool collide;
        switch (type)
        {
            case ObstacleType.Full:
                collide = true;
                break;
            case ObstacleType.Low:
                collide = player.CurrentPose != PlayerController.Pose.Jump;
                break;
            case ObstacleType.High:
                collide = player.CurrentPose != PlayerController.Pose.Slide;
                break;
            default:
                collide = false;
                break;
        }

        if (collide)
        {
            GameManager.Instance.GameOver();
        }
    }
}
