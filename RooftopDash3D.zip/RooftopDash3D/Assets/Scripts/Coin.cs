using UnityEngine;

// Attach to the coin prefab. Collider must have "Is Trigger" checked.
public class Coin : MonoBehaviour
{
    public float scoreValue = 12f;
    public float spinSpeed = 220f;

    void Update()
    {
        transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.World);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<PlayerController>() == null) return;
        GameManager.Instance.AddScore(scoreValue);
        Destroy(gameObject);
    }
}
