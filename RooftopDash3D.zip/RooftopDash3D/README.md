# Rooftop Dash 3D — Unity Setup Guide

This is a full 3D endless runner (Temple Run / Subway Surfers style): the camera
sits behind a running character, the world scrolls toward you with real depth,
lighting, and shadows, and you dodge obstacles by switching lanes, jumping, and
sliding.

The 7 C# scripts in `Assets/Scripts` are complete and functional. Unity itself
has to be installed on your machine to open, wire up, and run this — it's a
desktop editor, not something that runs in a browser or a chat window. Follow
the steps below and you'll have it running in about 20–30 minutes.

## 1. Install Unity

1. Download **Unity Hub**: https://unity.com/download
2. In Unity Hub, install the latest **LTS** editor version (2022 LTS or newer).
3. Create a new project → template **3D (Core)** → name it `RooftopDash3D`.

## 2. Copy in the scripts

Copy the entire `Assets/Scripts` folder from this download into your new
project's `Assets` folder (so you end up with
`YourProject/Assets/Scripts/*.cs`). Unity will compile them automatically —
check the Console window for errors (there shouldn't be any).

## 3. Build the obstacle & coin prefabs

Create each of these as a **GameObject → 3D Object**, add the listed
component, then drag it into a new `Assets/Prefabs` folder to make it a
prefab (then delete the instance from the scene).

| Prefab | Base object | Scale (approx) | Add script | Collider |
|---|---|---|---|---|
| `LowObstacle` | Cube | (1.4, 0.8, 0.6) | `Obstacle`, type = **Low** | Box Collider, **Is Trigger** ✓ |
| `HighObstacle` | Cube | (1.4, 0.3, 0.3), positioned ~1.4m up (a bar at head height) | `Obstacle`, type = **High** | Box Collider, **Is Trigger** ✓ |
| `FullObstacle` | Cube | (1.4, 2.2, 0.4) | `Obstacle`, type = **Full** | Box Collider, **Is Trigger** ✓ |
| `Coin` | Sphere | (0.4, 0.4, 0.4) | `Coin` | Sphere Collider, **Is Trigger** ✓ |

Give each a bright, readable material/color (e.g. red for Full, amber for Low,
cyan for High, gold for Coin) so they're easy to read while running.

## 4. Build the road tile prefab

1. Create a **Cube**, name it `RoadTile`, scale to about `(8, 0.2, 10)` so it's
   a flat slab 10 units long (matches `tileLength` in the scripts) and wide
   enough to cover all 3 lanes. Give it a dark road-like material.
   **Leave its Box Collider as a normal (non-trigger) collider** — the player
   needs to physically stand on it.
2. Add the `TileObstacleSpawner` script to it.
3. In the Inspector, drag your 4 prefabs from step 3 into the matching slots
   (`Low Obstacle Prefab`, `High Obstacle Prefab`, `Full Obstacle Prefab`,
   `Coin Prefab`). Leave `Lane X` as `-2.5, 0, 2.5` and `Tile Length` as `10`.
4. Drag `RoadTile` into `Assets/Prefabs` to make it a prefab, then delete the
   instance from the scene (the spawner script will create copies at runtime).

## 5. Build the player

1. Create a **Capsule**, name it `Player`.
2. Remove the default **Capsule Collider** component (right-click it → Remove
   Component).
3. Add Component → **Character Controller**. Set Height `2`, Center `(0, 1, 0)`,
   Radius `0.5`.
4. Add Component → **Rigidbody**. Check **Is Kinematic** and uncheck **Use
   Gravity** (this just makes trigger detection between the player and
   obstacles/coins fully reliable — the CharacterController still handles all
   actual movement).
5. Add the `PlayerController` script. Leave `Lane Positions` as `-2.5, 0, 2.5`.
6. Position the Player at roughly `(0, 1, 0)`.

## 6. Camera

1. Select `Main Camera`.
2. Add the `CameraFollow` script.
3. Drag `Player` into the `Target` field. Leave `Offset` as `(0, 4, -7)`.

## 7. Tile spawner

1. Create an empty GameObject, name it `TileSpawner`.
2. Add the `TileSpawner` script.
3. Drag `Player` into `Player`, and your `RoadTile` prefab into `Tile Prefab`.
4. Leave `Tiles On Screen` = 6, `Tile Length` = 10.

## 8. UI (score + game over)

1. Right-click in Hierarchy → **UI → Text - TextMeshPro** (import TMP essentials
   if prompted) for a `ScoreText` and a `BestScoreText`, positioned top-left.
2. Create a `GameOverPanel` (UI → Panel), initially it'll show — that's fine,
   the script disables it at Start. Add a `FinalScoreText` inside it and a
   **Restart** Button.
3. On the Button's `OnClick`, add an event pointing at a `GameManager`
   GameObject's `Restart()` method (create that GameObject next).
4. Create an empty GameObject `GameManager`, add the `GameManager` script, and
   drag your Score/Best/Panel/FinalScore UI elements into its Inspector slots.

   > Note: the script uses the legacy `UnityEngine.UI.Text` type. If you use
   > TextMeshPro instead, change the `Text` fields in `GameManager.cs` to
   > `TMPro.TextMeshProUGUI` (one-line find/replace).

## 9. Lighting & polish (optional but recommended)

- Window → Rendering → Lighting → enable **Fog** for atmospheric depth on the
  skyline.
- Add a warm-colored Directional Light angled low for a "dusk" look, matching
  the original browser prototype's mood.
- Add simple side buildings (scaled cubes) along the road for skyline detail —
  they don't need scripts, just static dressing.

## 10. Play

Press **Play**. Arrow keys / WASD to switch lanes, Space/Up to jump, Down to
slide (or swipe on a touch device/build). When you're happy with it, **File →
Build Settings** to build a real standalone .exe / .app, or an Android/iOS
build.

## Tuning knobs

- `GameManager`: `startSpeed`, `maxSpeed`, `speedRampPerSecond` control pacing.
- `TileObstacleSpawner.Populate()`: the probability thresholds (0.38, 0.68,
  0.86) control how often each obstacle pattern shows up — nudge these to
  make the game easier/harder.
- `PlayerController`: `jumpHeight`, `slideDuration`, `laneChangeSpeed` control
  how the controls feel.
